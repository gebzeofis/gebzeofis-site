export default function Home() {
return (
<main style={{ padding: "20px", fontFamily: "Arial" }}>
<h1>Gebze Ofis</h1>
<p>Kitap ve kırtasiye alışverişinizi kolayca yapın. Güvenli ödeme ve hızlı teslimat avantajı!</p>
</main>
);
}